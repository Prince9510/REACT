import React, { Component } from 'react'
import Index from './Component/Index'

export default class App extends Component {
  render() {
    return (
      <div>
        <Index/>
      </div>
    )
  }
}
